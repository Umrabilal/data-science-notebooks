```python
# Getting the data ready
## Choosing machine learning model
### Fit model
#### evaluate model
##### Improve the model
##### saving the model
###### Summary
```


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import sklearn
```


```python
df = pd.read_csv("heart_disease_uci.csv")
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>age</th>
      <th>sex</th>
      <th>dataset</th>
      <th>cp</th>
      <th>trestbps</th>
      <th>chol</th>
      <th>fbs</th>
      <th>restecg</th>
      <th>thalch</th>
      <th>exang</th>
      <th>oldpeak</th>
      <th>slope</th>
      <th>ca</th>
      <th>thal</th>
      <th>num</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>63</td>
      <td>Male</td>
      <td>Cleveland</td>
      <td>typical angina</td>
      <td>145.0</td>
      <td>233.0</td>
      <td>True</td>
      <td>lv hypertrophy</td>
      <td>150.0</td>
      <td>False</td>
      <td>2.3</td>
      <td>downsloping</td>
      <td>0.0</td>
      <td>fixed defect</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>67</td>
      <td>Male</td>
      <td>Cleveland</td>
      <td>asymptomatic</td>
      <td>160.0</td>
      <td>286.0</td>
      <td>False</td>
      <td>lv hypertrophy</td>
      <td>108.0</td>
      <td>True</td>
      <td>1.5</td>
      <td>flat</td>
      <td>3.0</td>
      <td>normal</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>67</td>
      <td>Male</td>
      <td>Cleveland</td>
      <td>asymptomatic</td>
      <td>120.0</td>
      <td>229.0</td>
      <td>False</td>
      <td>lv hypertrophy</td>
      <td>129.0</td>
      <td>True</td>
      <td>2.6</td>
      <td>flat</td>
      <td>2.0</td>
      <td>reversable defect</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>37</td>
      <td>Male</td>
      <td>Cleveland</td>
      <td>non-anginal</td>
      <td>130.0</td>
      <td>250.0</td>
      <td>False</td>
      <td>normal</td>
      <td>187.0</td>
      <td>False</td>
      <td>3.5</td>
      <td>downsloping</td>
      <td>0.0</td>
      <td>normal</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>41</td>
      <td>Female</td>
      <td>Cleveland</td>
      <td>atypical angina</td>
      <td>130.0</td>
      <td>204.0</td>
      <td>False</td>
      <td>lv hypertrophy</td>
      <td>172.0</td>
      <td>False</td>
      <td>1.4</td>
      <td>upsloping</td>
      <td>0.0</td>
      <td>normal</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.isnull().sum()
```




    id            0
    age           0
    sex           0
    dataset       0
    cp            0
    trestbps     59
    chol         30
    fbs          90
    restecg       2
    thalch       55
    exang        55
    oldpeak      62
    slope       309
    ca          611
    thal        486
    num           0
    dtype: int64




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 920 entries, 0 to 919
    Data columns (total 16 columns):
     #   Column    Non-Null Count  Dtype  
    ---  ------    --------------  -----  
     0   id        920 non-null    int64  
     1   age       920 non-null    int64  
     2   sex       920 non-null    object 
     3   dataset   920 non-null    object 
     4   cp        920 non-null    object 
     5   trestbps  861 non-null    float64
     6   chol      890 non-null    float64
     7   fbs       830 non-null    object 
     8   restecg   918 non-null    object 
     9   thalch    865 non-null    float64
     10  exang     865 non-null    object 
     11  oldpeak   858 non-null    float64
     12  slope     611 non-null    object 
     13  ca        309 non-null    float64
     14  thal      434 non-null    object 
     15  num       920 non-null    int64  
    dtypes: float64(5), int64(3), object(8)
    memory usage: 115.1+ KB
    


```python
df.isnull().mean() * 100
```




    id           0.000000
    age          0.000000
    sex          0.000000
    dataset      0.000000
    cp           0.000000
    trestbps     6.413043
    chol         3.260870
    fbs          9.782609
    restecg      0.217391
    thalch       5.978261
    exang        5.978261
    oldpeak      6.739130
    slope       33.586957
    ca          66.413043
    thal        52.826087
    num          0.000000
    dtype: float64




```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>age</th>
      <th>trestbps</th>
      <th>chol</th>
      <th>thalch</th>
      <th>oldpeak</th>
      <th>ca</th>
      <th>num</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>920.000000</td>
      <td>920.000000</td>
      <td>861.000000</td>
      <td>890.000000</td>
      <td>865.000000</td>
      <td>858.000000</td>
      <td>309.000000</td>
      <td>920.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>460.500000</td>
      <td>53.510870</td>
      <td>132.132404</td>
      <td>199.130337</td>
      <td>137.545665</td>
      <td>0.878788</td>
      <td>0.676375</td>
      <td>0.995652</td>
    </tr>
    <tr>
      <th>std</th>
      <td>265.725422</td>
      <td>9.424685</td>
      <td>19.066070</td>
      <td>110.780810</td>
      <td>25.926276</td>
      <td>1.091226</td>
      <td>0.935653</td>
      <td>1.142693</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>28.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>60.000000</td>
      <td>-2.600000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>230.750000</td>
      <td>47.000000</td>
      <td>120.000000</td>
      <td>175.000000</td>
      <td>120.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>460.500000</td>
      <td>54.000000</td>
      <td>130.000000</td>
      <td>223.000000</td>
      <td>140.000000</td>
      <td>0.500000</td>
      <td>0.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>690.250000</td>
      <td>60.000000</td>
      <td>140.000000</td>
      <td>268.000000</td>
      <td>157.000000</td>
      <td>1.500000</td>
      <td>1.000000</td>
      <td>2.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>920.000000</td>
      <td>77.000000</td>
      <td>200.000000</td>
      <td>603.000000</td>
      <td>202.000000</td>
      <td>6.200000</td>
      <td>3.000000</td>
      <td>4.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Fill numeric columns with median
df.fillna({
    'trestbps': df['trestbps'].median(),
    'chol': df['chol'].median(),
    'thalch': df['thalch'].median(),
    'oldpeak': df['oldpeak'].median(),
}, inplace=True)
```


```python
df.isna().sum()
```




    id            0
    age           0
    sex           0
    dataset       0
    cp            0
    trestbps      0
    chol          0
    fbs          90
    restecg       2
    thalch        0
    exang        55
    oldpeak       0
    slope       309
    ca          611
    thal        486
    num           0
    dtype: int64




```python
# Fill categorical/binary columns with mode values safely
fill_values = {
    'fbs': df['fbs'].mode()[0],
    'restecg': df['restecg'].mode()[0],
    'exang': df['exang'].mode()[0],
}

df = df.fillna(value=fill_values)
df = df.infer_objects(copy=False)
```

    C:\Users\umrab\AppData\Local\Temp\ipykernel_6564\852500911.py:8: FutureWarning: Downcasting object dtype arrays on .fillna, .ffill, .bfill is deprecated and will change in a future version. Call result.infer_objects(copy=False) instead. To opt-in to the future behavior, set `pd.set_option('future.no_silent_downcasting', True)`
      df = df.fillna(value=fill_values)
    


```python
df.isna().sum()
```




    id            0
    age           0
    sex           0
    dataset       0
    cp            0
    trestbps      0
    chol          0
    fbs           0
    restecg       0
    thalch        0
    exang         0
    oldpeak       0
    slope       309
    ca          611
    thal        486
    num           0
    dtype: int64




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 920 entries, 0 to 919
    Data columns (total 16 columns):
     #   Column    Non-Null Count  Dtype  
    ---  ------    --------------  -----  
     0   id        920 non-null    int64  
     1   age       920 non-null    int64  
     2   sex       920 non-null    object 
     3   dataset   920 non-null    object 
     4   cp        920 non-null    object 
     5   trestbps  920 non-null    float64
     6   chol      920 non-null    float64
     7   fbs       920 non-null    bool   
     8   restecg   920 non-null    object 
     9   thalch    920 non-null    float64
     10  exang     920 non-null    bool   
     11  oldpeak   920 non-null    float64
     12  slope     611 non-null    object 
     13  ca        309 non-null    float64
     14  thal      434 non-null    object 
     15  num       920 non-null    int64  
    dtypes: bool(2), float64(5), int64(3), object(6)
    memory usage: 102.6+ KB
    


```python
# Handle slope (fill with mode)
df['slope'] = df['slope'].fillna(df['slope'].mode()[0])
df['ca'] = df['ca'].fillna(df['ca'].mode()[0])
df['thal'] = df['thal'].fillna(df['thal'].mode()[0])
```


```python
df.isna().sum()
```




    id          0
    age         0
    sex         0
    dataset     0
    cp          0
    trestbps    0
    chol        0
    fbs         0
    restecg     0
    thalch      0
    exang       0
    oldpeak     0
    slope       0
    ca          0
    thal        0
    num         0
    dtype: int64




```python
df.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>age</th>
      <th>sex</th>
      <th>dataset</th>
      <th>cp</th>
      <th>trestbps</th>
      <th>chol</th>
      <th>fbs</th>
      <th>restecg</th>
      <th>thalch</th>
      <th>exang</th>
      <th>oldpeak</th>
      <th>slope</th>
      <th>ca</th>
      <th>thal</th>
      <th>num</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>915</th>
      <td>916</td>
      <td>54</td>
      <td>Female</td>
      <td>VA Long Beach</td>
      <td>asymptomatic</td>
      <td>127.0</td>
      <td>333.0</td>
      <td>True</td>
      <td>st-t abnormality</td>
      <td>154.0</td>
      <td>False</td>
      <td>0.0</td>
      <td>flat</td>
      <td>0.0</td>
      <td>normal</td>
      <td>1</td>
    </tr>
    <tr>
      <th>916</th>
      <td>917</td>
      <td>62</td>
      <td>Male</td>
      <td>VA Long Beach</td>
      <td>typical angina</td>
      <td>130.0</td>
      <td>139.0</td>
      <td>False</td>
      <td>st-t abnormality</td>
      <td>140.0</td>
      <td>False</td>
      <td>0.5</td>
      <td>flat</td>
      <td>0.0</td>
      <td>normal</td>
      <td>0</td>
    </tr>
    <tr>
      <th>917</th>
      <td>918</td>
      <td>55</td>
      <td>Male</td>
      <td>VA Long Beach</td>
      <td>asymptomatic</td>
      <td>122.0</td>
      <td>223.0</td>
      <td>True</td>
      <td>st-t abnormality</td>
      <td>100.0</td>
      <td>False</td>
      <td>0.0</td>
      <td>flat</td>
      <td>0.0</td>
      <td>fixed defect</td>
      <td>2</td>
    </tr>
    <tr>
      <th>918</th>
      <td>919</td>
      <td>58</td>
      <td>Male</td>
      <td>VA Long Beach</td>
      <td>asymptomatic</td>
      <td>130.0</td>
      <td>385.0</td>
      <td>True</td>
      <td>lv hypertrophy</td>
      <td>140.0</td>
      <td>False</td>
      <td>0.5</td>
      <td>flat</td>
      <td>0.0</td>
      <td>normal</td>
      <td>0</td>
    </tr>
    <tr>
      <th>919</th>
      <td>920</td>
      <td>62</td>
      <td>Male</td>
      <td>VA Long Beach</td>
      <td>atypical angina</td>
      <td>120.0</td>
      <td>254.0</td>
      <td>False</td>
      <td>lv hypertrophy</td>
      <td>93.0</td>
      <td>True</td>
      <td>0.0</td>
      <td>flat</td>
      <td>0.0</td>
      <td>normal</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Replace o with median
# Replace zero values with median
df.loc[df['trestbps'] == 0, 'trestbps'] = df['trestbps'].median()
df.loc[df['chol'] == 0, 'chol'] = df['chol'].median()

```


```python
#drop id column
df.drop(columns=['id'], inplace=True)
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>sex</th>
      <th>dataset</th>
      <th>cp</th>
      <th>trestbps</th>
      <th>chol</th>
      <th>fbs</th>
      <th>restecg</th>
      <th>thalch</th>
      <th>exang</th>
      <th>oldpeak</th>
      <th>slope</th>
      <th>ca</th>
      <th>thal</th>
      <th>num</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>63</td>
      <td>Male</td>
      <td>Cleveland</td>
      <td>typical angina</td>
      <td>145.0</td>
      <td>233.0</td>
      <td>True</td>
      <td>lv hypertrophy</td>
      <td>150.0</td>
      <td>False</td>
      <td>2.3</td>
      <td>downsloping</td>
      <td>0.0</td>
      <td>fixed defect</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>67</td>
      <td>Male</td>
      <td>Cleveland</td>
      <td>asymptomatic</td>
      <td>160.0</td>
      <td>286.0</td>
      <td>False</td>
      <td>lv hypertrophy</td>
      <td>108.0</td>
      <td>True</td>
      <td>1.5</td>
      <td>flat</td>
      <td>3.0</td>
      <td>normal</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>67</td>
      <td>Male</td>
      <td>Cleveland</td>
      <td>asymptomatic</td>
      <td>120.0</td>
      <td>229.0</td>
      <td>False</td>
      <td>lv hypertrophy</td>
      <td>129.0</td>
      <td>True</td>
      <td>2.6</td>
      <td>flat</td>
      <td>2.0</td>
      <td>reversable defect</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>37</td>
      <td>Male</td>
      <td>Cleveland</td>
      <td>non-anginal</td>
      <td>130.0</td>
      <td>250.0</td>
      <td>False</td>
      <td>normal</td>
      <td>187.0</td>
      <td>False</td>
      <td>3.5</td>
      <td>downsloping</td>
      <td>0.0</td>
      <td>normal</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>41</td>
      <td>Female</td>
      <td>Cleveland</td>
      <td>atypical angina</td>
      <td>130.0</td>
      <td>204.0</td>
      <td>False</td>
      <td>lv hypertrophy</td>
      <td>172.0</td>
      <td>False</td>
      <td>1.4</td>
      <td>upsloping</td>
      <td>0.0</td>
      <td>normal</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# counts the value of patients who have disease or not
df['num'].value_counts()
```




    num
    0    411
    1    265
    2    109
    3    107
    4     28
    Name: count, dtype: int64




```python
#visualization of patient who have disease or not
df.hist(figsize=(10,8))
plt.show()
```


    
![png](output_20_0.png)
    



```python
df.dtypes
```




    age           int64
    sex          object
    dataset      object
    cp           object
    trestbps    float64
    chol        float64
    fbs            bool
    restecg      object
    thalch      float64
    exang          bool
    oldpeak     float64
    slope        object
    ca          float64
    thal         object
    num           int64
    dtype: object




```python
# Numeric column [age, trestbps, chol, thalch, oldpeak, ca, num]
# Boolean column [fbs, exang]
# Categorical column which need encoding [sex, dataset, cp, restecg, slope, thal]
```


```python
# Convert boolean to integer
df['fbs'] = df['fbs'].astype(int)
df['exang'] = df['exang'].astype(int)
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>sex</th>
      <th>dataset</th>
      <th>cp</th>
      <th>trestbps</th>
      <th>chol</th>
      <th>fbs</th>
      <th>restecg</th>
      <th>thalch</th>
      <th>exang</th>
      <th>oldpeak</th>
      <th>slope</th>
      <th>ca</th>
      <th>thal</th>
      <th>num</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>63</td>
      <td>Male</td>
      <td>Cleveland</td>
      <td>typical angina</td>
      <td>145.0</td>
      <td>233.0</td>
      <td>1</td>
      <td>lv hypertrophy</td>
      <td>150.0</td>
      <td>0</td>
      <td>2.3</td>
      <td>downsloping</td>
      <td>0.0</td>
      <td>fixed defect</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>67</td>
      <td>Male</td>
      <td>Cleveland</td>
      <td>asymptomatic</td>
      <td>160.0</td>
      <td>286.0</td>
      <td>0</td>
      <td>lv hypertrophy</td>
      <td>108.0</td>
      <td>1</td>
      <td>1.5</td>
      <td>flat</td>
      <td>3.0</td>
      <td>normal</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>67</td>
      <td>Male</td>
      <td>Cleveland</td>
      <td>asymptomatic</td>
      <td>120.0</td>
      <td>229.0</td>
      <td>0</td>
      <td>lv hypertrophy</td>
      <td>129.0</td>
      <td>1</td>
      <td>2.6</td>
      <td>flat</td>
      <td>2.0</td>
      <td>reversable defect</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>37</td>
      <td>Male</td>
      <td>Cleveland</td>
      <td>non-anginal</td>
      <td>130.0</td>
      <td>250.0</td>
      <td>0</td>
      <td>normal</td>
      <td>187.0</td>
      <td>0</td>
      <td>3.5</td>
      <td>downsloping</td>
      <td>0.0</td>
      <td>normal</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>41</td>
      <td>Female</td>
      <td>Cleveland</td>
      <td>atypical angina</td>
      <td>130.0</td>
      <td>204.0</td>
      <td>0</td>
      <td>lv hypertrophy</td>
      <td>172.0</td>
      <td>0</td>
      <td>1.4</td>
      <td>upsloping</td>
      <td>0.0</td>
      <td>normal</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df['sex'] = df['sex'].map({'Female': 0, 'Male': 1})
```


```python
categorical_cols = ['sex', 'cp', 'restecg', 'slope', 'thal', 'dataset']

df_encoded = pd.get_dummies(df, columns=categorical_cols, drop_first=True)
```


```python
df['sex'].unique()
df['cp'].unique()
df['restecg'].unique()
df['slope'].unique()
df['thal'].unique()
```




    array(['fixed defect', 'normal', 'reversable defect'], dtype=object)




```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>sex</th>
      <th>dataset</th>
      <th>cp</th>
      <th>trestbps</th>
      <th>chol</th>
      <th>fbs</th>
      <th>restecg</th>
      <th>thalch</th>
      <th>exang</th>
      <th>oldpeak</th>
      <th>slope</th>
      <th>ca</th>
      <th>thal</th>
      <th>num</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>63</td>
      <td>1</td>
      <td>Cleveland</td>
      <td>typical angina</td>
      <td>145.0</td>
      <td>233.0</td>
      <td>1</td>
      <td>lv hypertrophy</td>
      <td>150.0</td>
      <td>0</td>
      <td>2.3</td>
      <td>downsloping</td>
      <td>0.0</td>
      <td>fixed defect</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>67</td>
      <td>1</td>
      <td>Cleveland</td>
      <td>asymptomatic</td>
      <td>160.0</td>
      <td>286.0</td>
      <td>0</td>
      <td>lv hypertrophy</td>
      <td>108.0</td>
      <td>1</td>
      <td>1.5</td>
      <td>flat</td>
      <td>3.0</td>
      <td>normal</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>67</td>
      <td>1</td>
      <td>Cleveland</td>
      <td>asymptomatic</td>
      <td>120.0</td>
      <td>229.0</td>
      <td>0</td>
      <td>lv hypertrophy</td>
      <td>129.0</td>
      <td>1</td>
      <td>2.6</td>
      <td>flat</td>
      <td>2.0</td>
      <td>reversable defect</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>37</td>
      <td>1</td>
      <td>Cleveland</td>
      <td>non-anginal</td>
      <td>130.0</td>
      <td>250.0</td>
      <td>0</td>
      <td>normal</td>
      <td>187.0</td>
      <td>0</td>
      <td>3.5</td>
      <td>downsloping</td>
      <td>0.0</td>
      <td>normal</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>41</td>
      <td>0</td>
      <td>Cleveland</td>
      <td>atypical angina</td>
      <td>130.0</td>
      <td>204.0</td>
      <td>0</td>
      <td>lv hypertrophy</td>
      <td>172.0</td>
      <td>0</td>
      <td>1.4</td>
      <td>upsloping</td>
      <td>0.0</td>
      <td>normal</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df=df.drop(columns=['dataset'])
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>sex</th>
      <th>cp</th>
      <th>trestbps</th>
      <th>chol</th>
      <th>fbs</th>
      <th>restecg</th>
      <th>thalch</th>
      <th>exang</th>
      <th>oldpeak</th>
      <th>slope</th>
      <th>ca</th>
      <th>thal</th>
      <th>num</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>63</td>
      <td>1</td>
      <td>typical angina</td>
      <td>145.0</td>
      <td>233.0</td>
      <td>1</td>
      <td>lv hypertrophy</td>
      <td>150.0</td>
      <td>0</td>
      <td>2.3</td>
      <td>downsloping</td>
      <td>0.0</td>
      <td>fixed defect</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>67</td>
      <td>1</td>
      <td>asymptomatic</td>
      <td>160.0</td>
      <td>286.0</td>
      <td>0</td>
      <td>lv hypertrophy</td>
      <td>108.0</td>
      <td>1</td>
      <td>1.5</td>
      <td>flat</td>
      <td>3.0</td>
      <td>normal</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>67</td>
      <td>1</td>
      <td>asymptomatic</td>
      <td>120.0</td>
      <td>229.0</td>
      <td>0</td>
      <td>lv hypertrophy</td>
      <td>129.0</td>
      <td>1</td>
      <td>2.6</td>
      <td>flat</td>
      <td>2.0</td>
      <td>reversable defect</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>37</td>
      <td>1</td>
      <td>non-anginal</td>
      <td>130.0</td>
      <td>250.0</td>
      <td>0</td>
      <td>normal</td>
      <td>187.0</td>
      <td>0</td>
      <td>3.5</td>
      <td>downsloping</td>
      <td>0.0</td>
      <td>normal</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>41</td>
      <td>0</td>
      <td>atypical angina</td>
      <td>130.0</td>
      <td>204.0</td>
      <td>0</td>
      <td>lv hypertrophy</td>
      <td>172.0</td>
      <td>0</td>
      <td>1.4</td>
      <td>upsloping</td>
      <td>0.0</td>
      <td>normal</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Clean text and convert to numeric
df = df.apply(lambda x: x.str.strip().str.lower() if x.dtype == "object" else x)

df['cp'] = df['cp'].map({'typical angina': 0, 'atypical angina': 1, 'non-anginal': 2, 'asymptomatic': 3})
df['restecg'] = df['restecg'].map({'normal': 0, 'st-t abnormality': 1, 'lv hypertrophy': 2})
df['slope'] = df['slope'].map({'upsloping': 0, 'flat': 1, 'downsloping': 2})
df['thal'] = df['thal'].map({'normal': 1, 'fixed defect': 2, 'reversable defect': 3})

```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>sex</th>
      <th>cp</th>
      <th>trestbps</th>
      <th>chol</th>
      <th>fbs</th>
      <th>restecg</th>
      <th>thalch</th>
      <th>exang</th>
      <th>oldpeak</th>
      <th>slope</th>
      <th>ca</th>
      <th>thal</th>
      <th>num</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>63</td>
      <td>1</td>
      <td>0</td>
      <td>145.0</td>
      <td>233.0</td>
      <td>1</td>
      <td>2</td>
      <td>150.0</td>
      <td>0</td>
      <td>2.3</td>
      <td>2</td>
      <td>0.0</td>
      <td>2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>67</td>
      <td>1</td>
      <td>3</td>
      <td>160.0</td>
      <td>286.0</td>
      <td>0</td>
      <td>2</td>
      <td>108.0</td>
      <td>1</td>
      <td>1.5</td>
      <td>1</td>
      <td>3.0</td>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>67</td>
      <td>1</td>
      <td>3</td>
      <td>120.0</td>
      <td>229.0</td>
      <td>0</td>
      <td>2</td>
      <td>129.0</td>
      <td>1</td>
      <td>2.6</td>
      <td>1</td>
      <td>2.0</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>37</td>
      <td>1</td>
      <td>2</td>
      <td>130.0</td>
      <td>250.0</td>
      <td>0</td>
      <td>0</td>
      <td>187.0</td>
      <td>0</td>
      <td>3.5</td>
      <td>2</td>
      <td>0.0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>41</td>
      <td>0</td>
      <td>1</td>
      <td>130.0</td>
      <td>204.0</td>
      <td>0</td>
      <td>2</td>
      <td>172.0</td>
      <td>0</td>
      <td>1.4</td>
      <td>0</td>
      <td>0.0</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df = df.astype({'trestbps': 'int', 'chol': 'int', 'thalch': 'int', 'ca': 'int'})

```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>sex</th>
      <th>cp</th>
      <th>trestbps</th>
      <th>chol</th>
      <th>fbs</th>
      <th>restecg</th>
      <th>thalch</th>
      <th>exang</th>
      <th>oldpeak</th>
      <th>slope</th>
      <th>ca</th>
      <th>thal</th>
      <th>num</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>63</td>
      <td>1</td>
      <td>0</td>
      <td>145</td>
      <td>233</td>
      <td>1</td>
      <td>2</td>
      <td>150</td>
      <td>0</td>
      <td>2.3</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>67</td>
      <td>1</td>
      <td>3</td>
      <td>160</td>
      <td>286</td>
      <td>0</td>
      <td>2</td>
      <td>108</td>
      <td>1</td>
      <td>1.5</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>67</td>
      <td>1</td>
      <td>3</td>
      <td>120</td>
      <td>229</td>
      <td>0</td>
      <td>2</td>
      <td>129</td>
      <td>1</td>
      <td>2.6</td>
      <td>1</td>
      <td>2</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>37</td>
      <td>1</td>
      <td>2</td>
      <td>130</td>
      <td>250</td>
      <td>0</td>
      <td>0</td>
      <td>187</td>
      <td>0</td>
      <td>3.5</td>
      <td>2</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>41</td>
      <td>0</td>
      <td>1</td>
      <td>130</td>
      <td>204</td>
      <td>0</td>
      <td>2</td>
      <td>172</td>
      <td>0</td>
      <td>1.4</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df['num'].unique()
```




    array([0, 2, 1, 3, 4])




```python
df['num'] = df['num'].apply(lambda x: 1 if x > 0 else 0)
```


```python
df.rename(columns={'num': 'target'}, inplace=True)
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>sex</th>
      <th>cp</th>
      <th>trestbps</th>
      <th>chol</th>
      <th>fbs</th>
      <th>restecg</th>
      <th>thalch</th>
      <th>exang</th>
      <th>oldpeak</th>
      <th>slope</th>
      <th>ca</th>
      <th>thal</th>
      <th>target</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>63</td>
      <td>1</td>
      <td>0</td>
      <td>145</td>
      <td>233</td>
      <td>1</td>
      <td>2</td>
      <td>150</td>
      <td>0</td>
      <td>2.3</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>67</td>
      <td>1</td>
      <td>3</td>
      <td>160</td>
      <td>286</td>
      <td>0</td>
      <td>2</td>
      <td>108</td>
      <td>1</td>
      <td>1.5</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>67</td>
      <td>1</td>
      <td>3</td>
      <td>120</td>
      <td>229</td>
      <td>0</td>
      <td>2</td>
      <td>129</td>
      <td>1</td>
      <td>2.6</td>
      <td>1</td>
      <td>2</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>37</td>
      <td>1</td>
      <td>2</td>
      <td>130</td>
      <td>250</td>
      <td>0</td>
      <td>0</td>
      <td>187</td>
      <td>0</td>
      <td>3.5</td>
      <td>2</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>41</td>
      <td>0</td>
      <td>1</td>
      <td>130</td>
      <td>204</td>
      <td>0</td>
      <td>2</td>
      <td>172</td>
      <td>0</td>
      <td>1.4</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Save the cleaned dataset to a new CSV file
df.to_csv("cleaned_heart_dataset.csv", index=False)
```


```python
clean_heart_disease=pd.read_csv('cleaned_heart_dataset.csv')
```


```python
clean_heart_disease.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age</th>
      <th>sex</th>
      <th>cp</th>
      <th>trestbps</th>
      <th>chol</th>
      <th>fbs</th>
      <th>restecg</th>
      <th>thalch</th>
      <th>exang</th>
      <th>oldpeak</th>
      <th>slope</th>
      <th>ca</th>
      <th>thal</th>
      <th>target</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>63</td>
      <td>1</td>
      <td>0</td>
      <td>145</td>
      <td>233</td>
      <td>1</td>
      <td>2</td>
      <td>150</td>
      <td>0</td>
      <td>2.3</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>67</td>
      <td>1</td>
      <td>3</td>
      <td>160</td>
      <td>286</td>
      <td>0</td>
      <td>2</td>
      <td>108</td>
      <td>1</td>
      <td>1.5</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>67</td>
      <td>1</td>
      <td>3</td>
      <td>120</td>
      <td>229</td>
      <td>0</td>
      <td>2</td>
      <td>129</td>
      <td>1</td>
      <td>2.6</td>
      <td>1</td>
      <td>2</td>
      <td>3</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>37</td>
      <td>1</td>
      <td>2</td>
      <td>130</td>
      <td>250</td>
      <td>0</td>
      <td>0</td>
      <td>187</td>
      <td>0</td>
      <td>3.5</td>
      <td>2</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>41</td>
      <td>0</td>
      <td>1</td>
      <td>130</td>
      <td>204</td>
      <td>0</td>
      <td>2</td>
      <td>172</td>
      <td>0</td>
      <td>1.4</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
x = clean_heart_disease.drop('target', axis=1)
y = clean_heart_disease['target']
```


```python
y
```




    0      0
    1      1
    2      1
    3      0
    4      0
          ..
    915    1
    916    0
    917    1
    918    0
    919    1
    Name: target, Length: 920, dtype: int64




```python
# choose machine learning model
from sklearn.ensemble import RandomForestClassifier
clf = RandomForestClassifier()
clf.get_params()
```




    {'bootstrap': True,
     'ccp_alpha': 0.0,
     'class_weight': None,
     'criterion': 'gini',
     'max_depth': None,
     'max_features': 'sqrt',
     'max_leaf_nodes': None,
     'max_samples': None,
     'min_impurity_decrease': 0.0,
     'min_samples_leaf': 1,
     'min_samples_split': 2,
     'min_weight_fraction_leaf': 0.0,
     'monotonic_cst': None,
     'n_estimators': 100,
     'n_jobs': None,
     'oob_score': False,
     'random_state': None,
     'verbose': 0,
     'warm_start': False}




```python
## fit the model befor fit the model split data into train and test
from sklearn.model_selection import train_test_split
#x_train x_test, y_train, y_test = train_test_split(x, y, test_size=0.3)
```


```python
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.3)
```


```python
clf.fit(x_train,y_train)
```




<style>#sk-container-id-1 {
  /* Definition of color scheme common for light and dark mode */
  --sklearn-color-text: #000;
  --sklearn-color-text-muted: #666;
  --sklearn-color-line: gray;
  /* Definition of color scheme for unfitted estimators */
  --sklearn-color-unfitted-level-0: #fff5e6;
  --sklearn-color-unfitted-level-1: #f6e4d2;
  --sklearn-color-unfitted-level-2: #ffe0b3;
  --sklearn-color-unfitted-level-3: chocolate;
  /* Definition of color scheme for fitted estimators */
  --sklearn-color-fitted-level-0: #f0f8ff;
  --sklearn-color-fitted-level-1: #d4ebff;
  --sklearn-color-fitted-level-2: #b3dbfd;
  --sklearn-color-fitted-level-3: cornflowerblue;

  /* Specific color for light theme */
  --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, white)));
  --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, black)));
  --sklearn-color-icon: #696969;

  @media (prefers-color-scheme: dark) {
    /* Redefinition of color scheme for dark theme */
    --sklearn-color-text-on-default-background: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-background: var(--sg-background-color, var(--theme-background, var(--jp-layout-color0, #111)));
    --sklearn-color-border-box: var(--sg-text-color, var(--theme-code-foreground, var(--jp-content-font-color1, white)));
    --sklearn-color-icon: #878787;
  }
}

#sk-container-id-1 {
  color: var(--sklearn-color-text);
}

#sk-container-id-1 pre {
  padding: 0;
}

#sk-container-id-1 input.sk-hidden--visually {
  border: 0;
  clip: rect(1px 1px 1px 1px);
  clip: rect(1px, 1px, 1px, 1px);
  height: 1px;
  margin: -1px;
  overflow: hidden;
  padding: 0;
  position: absolute;
  width: 1px;
}

#sk-container-id-1 div.sk-dashed-wrapped {
  border: 1px dashed var(--sklearn-color-line);
  margin: 0 0.4em 0.5em 0.4em;
  box-sizing: border-box;
  padding-bottom: 0.4em;
  background-color: var(--sklearn-color-background);
}

#sk-container-id-1 div.sk-container {
  /* jupyter's `normalize.less` sets `[hidden] { display: none; }`
     but bootstrap.min.css set `[hidden] { display: none !important; }`
     so we also need the `!important` here to be able to override the
     default hidden behavior on the sphinx rendered scikit-learn.org.
     See: https://github.com/scikit-learn/scikit-learn/issues/21755 */
  display: inline-block !important;
  position: relative;
}

#sk-container-id-1 div.sk-text-repr-fallback {
  display: none;
}

div.sk-parallel-item,
div.sk-serial,
div.sk-item {
  /* draw centered vertical line to link estimators */
  background-image: linear-gradient(var(--sklearn-color-text-on-default-background), var(--sklearn-color-text-on-default-background));
  background-size: 2px 100%;
  background-repeat: no-repeat;
  background-position: center center;
}

/* Parallel-specific style estimator block */

#sk-container-id-1 div.sk-parallel-item::after {
  content: "";
  width: 100%;
  border-bottom: 2px solid var(--sklearn-color-text-on-default-background);
  flex-grow: 1;
}

#sk-container-id-1 div.sk-parallel {
  display: flex;
  align-items: stretch;
  justify-content: center;
  background-color: var(--sklearn-color-background);
  position: relative;
}

#sk-container-id-1 div.sk-parallel-item {
  display: flex;
  flex-direction: column;
}

#sk-container-id-1 div.sk-parallel-item:first-child::after {
  align-self: flex-end;
  width: 50%;
}

#sk-container-id-1 div.sk-parallel-item:last-child::after {
  align-self: flex-start;
  width: 50%;
}

#sk-container-id-1 div.sk-parallel-item:only-child::after {
  width: 0;
}

/* Serial-specific style estimator block */

#sk-container-id-1 div.sk-serial {
  display: flex;
  flex-direction: column;
  align-items: center;
  background-color: var(--sklearn-color-background);
  padding-right: 1em;
  padding-left: 1em;
}


/* Toggleable style: style used for estimator/Pipeline/ColumnTransformer box that is
clickable and can be expanded/collapsed.
- Pipeline and ColumnTransformer use this feature and define the default style
- Estimators will overwrite some part of the style using the `sk-estimator` class
*/

/* Pipeline and ColumnTransformer style (default) */

#sk-container-id-1 div.sk-toggleable {
  /* Default theme specific background. It is overwritten whether we have a
  specific estimator or a Pipeline/ColumnTransformer */
  background-color: var(--sklearn-color-background);
}

/* Toggleable label */
#sk-container-id-1 label.sk-toggleable__label {
  cursor: pointer;
  display: flex;
  width: 100%;
  margin-bottom: 0;
  padding: 0.5em;
  box-sizing: border-box;
  text-align: center;
  align-items: start;
  justify-content: space-between;
  gap: 0.5em;
}

#sk-container-id-1 label.sk-toggleable__label .caption {
  font-size: 0.6rem;
  font-weight: lighter;
  color: var(--sklearn-color-text-muted);
}

#sk-container-id-1 label.sk-toggleable__label-arrow:before {
  /* Arrow on the left of the label */
  content: "▸";
  float: left;
  margin-right: 0.25em;
  color: var(--sklearn-color-icon);
}

#sk-container-id-1 label.sk-toggleable__label-arrow:hover:before {
  color: var(--sklearn-color-text);
}

/* Toggleable content - dropdown */

#sk-container-id-1 div.sk-toggleable__content {
  display: none;
  text-align: left;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-1 div.sk-toggleable__content.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-1 div.sk-toggleable__content pre {
  margin: 0.2em;
  border-radius: 0.25em;
  color: var(--sklearn-color-text);
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-1 div.sk-toggleable__content.fitted pre {
  /* unfitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

#sk-container-id-1 input.sk-toggleable__control:checked~div.sk-toggleable__content {
  /* Expand drop-down */
  display: block;
  width: 100%;
  overflow: visible;
}

#sk-container-id-1 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {
  content: "▾";
}

/* Pipeline/ColumnTransformer-specific style */

#sk-container-id-1 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-1 div.sk-label.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator-specific style */

/* Colorize estimator box */
#sk-container-id-1 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-1 div.sk-estimator.fitted input.sk-toggleable__control:checked~label.sk-toggleable__label {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

#sk-container-id-1 div.sk-label label.sk-toggleable__label,
#sk-container-id-1 div.sk-label label {
  /* The background is the default theme color */
  color: var(--sklearn-color-text-on-default-background);
}

/* On hover, darken the color of the background */
#sk-container-id-1 div.sk-label:hover label.sk-toggleable__label {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-unfitted-level-2);
}

/* Label box, darken color on hover, fitted */
#sk-container-id-1 div.sk-label.fitted:hover label.sk-toggleable__label.fitted {
  color: var(--sklearn-color-text);
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Estimator label */

#sk-container-id-1 div.sk-label label {
  font-family: monospace;
  font-weight: bold;
  display: inline-block;
  line-height: 1.2em;
}

#sk-container-id-1 div.sk-label-container {
  text-align: center;
}

/* Estimator-specific */
#sk-container-id-1 div.sk-estimator {
  font-family: monospace;
  border: 1px dotted var(--sklearn-color-border-box);
  border-radius: 0.25em;
  box-sizing: border-box;
  margin-bottom: 0.5em;
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-0);
}

#sk-container-id-1 div.sk-estimator.fitted {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-0);
}

/* on hover */
#sk-container-id-1 div.sk-estimator:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-2);
}

#sk-container-id-1 div.sk-estimator.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-2);
}

/* Specification for estimator info (e.g. "i" and "?") */

/* Common style for "i" and "?" */

.sk-estimator-doc-link,
a:link.sk-estimator-doc-link,
a:visited.sk-estimator-doc-link {
  float: right;
  font-size: smaller;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1em;
  height: 1em;
  width: 1em;
  text-decoration: none !important;
  margin-left: 0.5em;
  text-align: center;
  /* unfitted */
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
  color: var(--sklearn-color-unfitted-level-1);
}

.sk-estimator-doc-link.fitted,
a:link.sk-estimator-doc-link.fitted,
a:visited.sk-estimator-doc-link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
div.sk-estimator:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover,
div.sk-label-container:hover .sk-estimator-doc-link:hover,
.sk-estimator-doc-link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

div.sk-estimator.fitted:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover,
div.sk-label-container:hover .sk-estimator-doc-link.fitted:hover,
.sk-estimator-doc-link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

/* Span, style for the box shown on hovering the info icon */
.sk-estimator-doc-link span {
  display: none;
  z-index: 9999;
  position: relative;
  font-weight: normal;
  right: .2ex;
  padding: .5ex;
  margin: .5ex;
  width: min-content;
  min-width: 20ex;
  max-width: 50ex;
  color: var(--sklearn-color-text);
  box-shadow: 2pt 2pt 4pt #999;
  /* unfitted */
  background: var(--sklearn-color-unfitted-level-0);
  border: .5pt solid var(--sklearn-color-unfitted-level-3);
}

.sk-estimator-doc-link.fitted span {
  /* fitted */
  background: var(--sklearn-color-fitted-level-0);
  border: var(--sklearn-color-fitted-level-3);
}

.sk-estimator-doc-link:hover span {
  display: block;
}

/* "?"-specific style due to the `<a>` HTML tag */

#sk-container-id-1 a.estimator_doc_link {
  float: right;
  font-size: 1rem;
  line-height: 1em;
  font-family: monospace;
  background-color: var(--sklearn-color-background);
  border-radius: 1rem;
  height: 1rem;
  width: 1rem;
  text-decoration: none;
  /* unfitted */
  color: var(--sklearn-color-unfitted-level-1);
  border: var(--sklearn-color-unfitted-level-1) 1pt solid;
}

#sk-container-id-1 a.estimator_doc_link.fitted {
  /* fitted */
  border: var(--sklearn-color-fitted-level-1) 1pt solid;
  color: var(--sklearn-color-fitted-level-1);
}

/* On hover */
#sk-container-id-1 a.estimator_doc_link:hover {
  /* unfitted */
  background-color: var(--sklearn-color-unfitted-level-3);
  color: var(--sklearn-color-background);
  text-decoration: none;
}

#sk-container-id-1 a.estimator_doc_link.fitted:hover {
  /* fitted */
  background-color: var(--sklearn-color-fitted-level-3);
}

.estimator-table summary {
    padding: .5rem;
    font-family: monospace;
    cursor: pointer;
}

.estimator-table details[open] {
    padding-left: 0.1rem;
    padding-right: 0.1rem;
    padding-bottom: 0.3rem;
}

.estimator-table .parameters-table {
    margin-left: auto !important;
    margin-right: auto !important;
}

.estimator-table .parameters-table tr:nth-child(odd) {
    background-color: #fff;
}

.estimator-table .parameters-table tr:nth-child(even) {
    background-color: #f6f6f6;
}

.estimator-table .parameters-table tr:hover {
    background-color: #e0e0e0;
}

.estimator-table table td {
    border: 1px solid rgba(106, 105, 104, 0.232);
}

.user-set td {
    color:rgb(255, 94, 0);
    text-align: left;
}

.user-set td.value pre {
    color:rgb(255, 94, 0) !important;
    background-color: transparent !important;
}

.default td {
    color: black;
    text-align: left;
}

.user-set td i,
.default td i {
    color: black;
}

.copy-paste-icon {
    background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA0NDggNTEyIj48IS0tIUZvbnQgQXdlc29tZSBGcmVlIDYuNy4yIGJ5IEBmb250YXdlc29tZSAtIGh0dHBzOi8vZm9udGF3ZXNvbWUuY29tIExpY2Vuc2UgLSBodHRwczovL2ZvbnRhd2Vzb21lLmNvbS9saWNlbnNlL2ZyZWUgQ29weXJpZ2h0IDIwMjUgRm9udGljb25zLCBJbmMuLS0+PHBhdGggZD0iTTIwOCAwTDMzMi4xIDBjMTIuNyAwIDI0LjkgNS4xIDMzLjkgMTQuMWw2Ny45IDY3LjljOSA5IDE0LjEgMjEuMiAxNC4xIDMzLjlMNDQ4IDMzNmMwIDI2LjUtMjEuNSA0OC00OCA0OGwtMTkyIDBjLTI2LjUgMC00OC0yMS41LTQ4LTQ4bDAtMjg4YzAtMjYuNSAyMS41LTQ4IDQ4LTQ4ek00OCAxMjhsODAgMCAwIDY0LTY0IDAgMCAyNTYgMTkyIDAgMC0zMiA2NCAwIDAgNDhjMCAyNi41LTIxLjUgNDgtNDggNDhMNDggNTEyYy0yNi41IDAtNDgtMjEuNS00OC00OEwwIDE3NmMwLTI2LjUgMjEuNS00OCA0OC00OHoiLz48L3N2Zz4=);
    background-repeat: no-repeat;
    background-size: 14px 14px;
    background-position: 0;
    display: inline-block;
    width: 14px;
    height: 14px;
    cursor: pointer;
}
</style><body><div id="sk-container-id-1" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>RandomForestClassifier()</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator fitted sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-1" type="checkbox" checked><label for="sk-estimator-id-1" class="sk-toggleable__label fitted sk-toggleable__label-arrow"><div><div>RandomForestClassifier</div></div><div><a class="sk-estimator-doc-link fitted" rel="noreferrer" target="_blank" href="https://scikit-learn.org/1.7/modules/generated/sklearn.ensemble.RandomForestClassifier.html">?<span>Documentation for RandomForestClassifier</span></a><span class="sk-estimator-doc-link fitted">i<span>Fitted</span></span></div></label><div class="sk-toggleable__content fitted" data-param-prefix="">
        <div class="estimator-table">
            <details>
                <summary>Parameters</summary>
                <table class="parameters-table">
                  <tbody>

        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('n_estimators',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">n_estimators&nbsp;</td>
            <td class="value">100</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('criterion',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">criterion&nbsp;</td>
            <td class="value">&#x27;gini&#x27;</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('max_depth',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">max_depth&nbsp;</td>
            <td class="value">None</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('min_samples_split',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">min_samples_split&nbsp;</td>
            <td class="value">2</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('min_samples_leaf',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">min_samples_leaf&nbsp;</td>
            <td class="value">1</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('min_weight_fraction_leaf',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">min_weight_fraction_leaf&nbsp;</td>
            <td class="value">0.0</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('max_features',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">max_features&nbsp;</td>
            <td class="value">&#x27;sqrt&#x27;</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('max_leaf_nodes',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">max_leaf_nodes&nbsp;</td>
            <td class="value">None</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('min_impurity_decrease',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">min_impurity_decrease&nbsp;</td>
            <td class="value">0.0</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('bootstrap',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">bootstrap&nbsp;</td>
            <td class="value">True</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('oob_score',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">oob_score&nbsp;</td>
            <td class="value">False</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('n_jobs',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">n_jobs&nbsp;</td>
            <td class="value">None</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('random_state',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">random_state&nbsp;</td>
            <td class="value">None</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('verbose',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">verbose&nbsp;</td>
            <td class="value">0</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('warm_start',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">warm_start&nbsp;</td>
            <td class="value">False</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('class_weight',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">class_weight&nbsp;</td>
            <td class="value">None</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('ccp_alpha',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">ccp_alpha&nbsp;</td>
            <td class="value">0.0</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('max_samples',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">max_samples&nbsp;</td>
            <td class="value">None</td>
        </tr>


        <tr class="default">
            <td><i class="copy-paste-icon"
                 onclick="copyToClipboard('monotonic_cst',
                          this.parentElement.nextElementSibling)"
            ></i></td>
            <td class="param">monotonic_cst&nbsp;</td>
            <td class="value">None</td>
        </tr>

                  </tbody>
                </table>
            </details>
        </div>
    </div></div></div></div></div><script>function copyToClipboard(text, element) {
    // Get the parameter prefix from the closest toggleable content
    const toggleableContent = element.closest('.sk-toggleable__content');
    const paramPrefix = toggleableContent ? toggleableContent.dataset.paramPrefix : '';
    const fullParamName = paramPrefix ? `${paramPrefix}${text}` : text;

    const originalStyle = element.style;
    const computedStyle = window.getComputedStyle(element);
    const originalWidth = computedStyle.width;
    const originalHTML = element.innerHTML.replace('Copied!', '');

    navigator.clipboard.writeText(fullParamName)
        .then(() => {
            element.style.width = originalWidth;
            element.style.color = 'green';
            element.innerHTML = "Copied!";

            setTimeout(() => {
                element.innerHTML = originalHTML;
                element.style = originalStyle;
            }, 2000);
        })
        .catch(err => {
            console.error('Failed to copy:', err);
            element.style.color = 'red';
            element.innerHTML = "Failed!";
            setTimeout(() => {
                element.innerHTML = originalHTML;
                element.style = originalStyle;
            }, 2000);
        });
    return false;
}

document.querySelectorAll('.fa-regular.fa-copy').forEach(function(element) {
    const toggleableContent = element.closest('.sk-toggleable__content');
    const paramPrefix = toggleableContent ? toggleableContent.dataset.paramPrefix : '';
    const paramName = element.parentElement.nextElementSibling.textContent.trim();
    const fullParamName = paramPrefix ? `${paramPrefix}${paramName}` : paramName;

    element.setAttribute('title', fullParamName);
});
</script></body>




```python
#evaluate the model
predict_y=clf.predict(x_test)
predict_y
```




    array([1, 0, 1, 0, 0, 1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 1,
           0, 1, 1, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 0, 0, 1, 1, 1, 1, 0, 0,
           0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 0, 1, 0, 0,
           1, 0, 1, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0, 1, 1, 0, 0,
           1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1,
           1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1,
           1, 1, 0, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0,
           0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1,
           1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 0, 1, 0, 0, 1, 0, 1, 1, 0, 0, 1,
           0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 1, 0, 0, 0, 0,
           0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 1, 0,
           1, 0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 0, 0, 1,
           0, 1, 1, 1, 0, 1, 0, 1, 1, 0, 0, 0])




```python
#accuracy check for seen data
clf.score(x_train,y_train)
```




    1.0




```python
#accuracy check for unseen data
clf.score(x_test,y_test)
```




    0.7717391304347826




```python
#improve the model
for i in range(10,200,10):
    print(f"running model with {i} estimators")
    clf= RandomForestClassifier(n_estimators=i).fit(x_train,y_train)
    print(f"accuracy is: {clf.score(x_test,y_test)}")
    
```

    running model with 10 estimators
    accuracy is: 0.7536231884057971
    running model with 20 estimators
    accuracy is: 0.7681159420289855
    running model with 30 estimators
    accuracy is: 0.7753623188405797
    running model with 40 estimators
    accuracy is: 0.7753623188405797
    running model with 50 estimators
    accuracy is: 0.7753623188405797
    running model with 60 estimators
    accuracy is: 0.7753623188405797
    running model with 70 estimators
    accuracy is: 0.7681159420289855
    running model with 80 estimators
    accuracy is: 0.7644927536231884
    running model with 90 estimators
    accuracy is: 0.7681159420289855
    running model with 100 estimators
    accuracy is: 0.7753623188405797
    running model with 110 estimators
    accuracy is: 0.7644927536231884
    running model with 120 estimators
    accuracy is: 0.7644927536231884
    running model with 130 estimators
    accuracy is: 0.7681159420289855
    running model with 140 estimators
    accuracy is: 0.7753623188405797
    running model with 150 estimators
    accuracy is: 0.7681159420289855
    running model with 160 estimators
    accuracy is: 0.7717391304347826
    running model with 170 estimators
    accuracy is: 0.7681159420289855
    running model with 180 estimators
    accuracy is: 0.75
    running model with 190 estimators
    accuracy is: 0.7862318840579711
    


```python
#save the model
import pickle
pickle.dump(clf,open('Heart_disease_prediction.pkl', 'wb'))
```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```


```python

```
